-- AlterEnum
ALTER TYPE "UserStatus" ADD VALUE 'DELETED';
