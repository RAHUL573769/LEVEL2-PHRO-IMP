[Requiremnet-Analysis](https://docs.google.com/document/d/10mkjS8boCQzW4xpsESyzwCCLJcM3hvLghyD_TeXPBx0/edit?usp=sharing)

[ER Diagram: 1](./ER_Diagram.png)
[ER Diagram: 2](./ER%20Diagram2.png)
