export const studentSearchableFields = [
  'email',
  'name.firstName',
  'presentAddress',
];
