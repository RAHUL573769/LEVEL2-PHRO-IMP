const CreateFaculty = () => {
  return (
    <div>
      <h1> This is CreateFaculty component </h1>
    </div>
  );
};

export default CreateFaculty;
