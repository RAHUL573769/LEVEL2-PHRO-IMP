const CreateAdmin = () => {
  return (
    <div>
      <h1> This is CreateAdmin component </h1>
    </div>
  );
};

export default CreateAdmin;
