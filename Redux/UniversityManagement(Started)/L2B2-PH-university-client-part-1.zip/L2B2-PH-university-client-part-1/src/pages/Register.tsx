const Register = () => {
  return (
    <div>
      <h1> This is Register component </h1>
    </div>
  );
};

export default Register;
