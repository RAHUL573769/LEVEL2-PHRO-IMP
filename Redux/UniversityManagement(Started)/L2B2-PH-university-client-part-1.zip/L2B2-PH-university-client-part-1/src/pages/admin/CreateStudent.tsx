const CreateStudent = () => {
  return (
    <div>
      <h1> This is CreateStudent component </h1>
    </div>
  );
};

export default CreateStudent;
