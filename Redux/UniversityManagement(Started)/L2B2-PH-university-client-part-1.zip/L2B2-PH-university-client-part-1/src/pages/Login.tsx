const Login = () => {
  return (
    <div>
      <h1> This is Login component </h1>
    </div>
  );
};

export default Login;
