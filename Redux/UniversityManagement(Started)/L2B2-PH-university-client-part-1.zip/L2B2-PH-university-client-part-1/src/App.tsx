import MainLayout from './components/layout/MainLayout';

function App() {
  return <MainLayout />;
}

export default App;
