export type TLoginUser = {
  id: string;
  password: string;
};
